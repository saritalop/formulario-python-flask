#!/bin/bash
source myenv/bin/activate
python app.py
