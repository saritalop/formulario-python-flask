
 // Obtener todos los botones de eliminar campo
 var eliminarBotones = document.querySelectorAll('.eliminar-campo');
 
 // Agregar un evento de clic a cada botón
 eliminarBotones.forEach(function(boton) {
     boton.addEventListener('click', function() {
         // Obtener el campo asociado al botón de eliminar
         var campoId = this.getAttribute('data-campo');
         var campo = document.getElementById('campo_' + campoId);
         // Eliminar el campo y su botón de eliminar del formulario
         campo.parentNode.removeChild(campo);
     });
 });
 
 // Función para agregar campos adicionales al formulario
function agregarNuevoCampo() {
     var nuevoCampoContainer = document.getElementById('nuevo-campo-container');
     // Toggle para mostrar u ocultar el contenedor de nuevo campo
     nuevoCampoContainer.style.display = (nuevoCampoContainer.style.display === 'none') ? 'block' : 'none';
 }

 // Agrega un event listener para el botón "Añadir Nuevo Campo"
 document.getElementById('btn-nuevo-campo').addEventListener('click', agregarNuevoCampo);

// Función para mostrar u ocultar los detalles del formulario
var detalleInfo = document.getElementById('detalle-info');

 document.getElementById('btn-detalle').addEventListener('click', function() {
     if (detalleInfo.style.display === 'none') {
         detalleInfo.style.display = 'block';
     } else {
         detalleInfo.style.display = 'none';
     }
 });
 
 document.getElementById('btn-guardar').addEventListener('click', function(event) {
    var formulario = document.getElementById('formulario');
    var archivoInput = document.getElementById('archivo');
 
    // Verificar si el formulario es válido
    if (formulario.checkValidity()) {
        // Verificar si se ha seleccionado un archivo y si es un archivo XLS
        if (archivoInput.files.length > 0) {
            var nombreArchivo = archivoInput.files[0].name;
            if (nombreArchivo.endsWith('.xls')) {
                alert("¡Guardado Correctamente!");
            } else {
                event.preventDefault();
                alert("Solo se aceptan archivos con extensión XLS.");
                // Limpiar el campo de selección de archivo
                archivoInput.value = "";
                // Recargar la página para limpiar otros campos y restablecer el estado
                window.location.reload();
                return; // Detener la ejecución del código
            }
        } else {
            // No se ha seleccionado ningún archivo, continuar con la operación de guardado
            alert("¡Guardado Correctamente!");
        }
    } else {
        // Evitar el envío del formulario si hay campos inválidos
        event.preventDefault();
        event.stopPropagation(); // Evitar la propagación del evento para prevenir comportamiento predeterminado
        alert("¡Campos requeridos!");
    }
});

 // Función para agregar campos adicionales al formulario
function cambiarPassword() {
     var cambiarPassword = document.getElementById('cambiar-password-container');
     // Toggle para mostrar u ocultar el contenedor de nuevo campo
     cambiarPassword.style.display = (cambiarPassword.style.display === 'none') ? 'block' : 'none';
 }

 // Agrega un event listener para el botón "Añadir Nuevo Campo"
 document.getElementById('btn-cambiar-password').addEventListener('click', cambiarPassword);

