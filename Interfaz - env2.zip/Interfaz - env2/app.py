#importaciones
from flask import Flask, render_template, request, redirect, url_for, flash, session
from cryptography.fernet import Fernet, InvalidToken
import os

# Instancia de flask 
app = Flask(__name__, static_folder='static')
app.secret_key = 'llave secreta'

#Donde se le da el nombre de la carpeta, para que alamcene los archivos XLS
UPLOAD_FOLDER = 'archivos'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Función para generar y guardar clave de encriptación si no existe
def generate_key():
    return Fernet.generate_key()

if not os.path.exists('secret.key'):
    with open('secret.key', 'wb') as key_file:
        key_file.write(generate_key())

with open('secret.key', 'rb') as key_file:
    key = key_file.read()

cipher_suite = Fernet(key)

# Funciones de encriptación y desencriptación
def encrypt_text(text):
    return cipher_suite.encrypt(text.encode()).decode()

def decrypt_text(encrypted_text):
    try:
        return cipher_suite.decrypt(encrypted_text.encode()).decode()
    except InvalidToken:
        return None

# Función para leer información del usuario desde el archivo
def read_user_info():
    users = {}
    try:
        with open('usuarios.txt', 'r') as file:
            for line in file:
                key, value = line.strip().split(' = ')
                users[key.strip()] = value.strip().strip("'")
    except FileNotFoundError:
        pass
    return users

# Función para encriptar credenciales existentes si no están encriptadas
def encrypt_existing_credentials():
    users = read_user_info()
    file_changed = False

    if 'username' in users:
        decrypted_username = decrypt_text(users['username'])
        if decrypted_username is None:  # Si no se puede descifrar, significa que no está encriptado
            encrypted_username = encrypt_text(users['username'])
            users['username'] = encrypted_username
            file_changed = True

    if 'password' in users:
        decrypted_password = decrypt_text(users['password'])
        if decrypted_password is None:  # Si no se puede descifrar, significa que no está encriptado
            encrypted_password = encrypt_text(users['password'])
            users['password'] = encrypted_password
            file_changed = True

    if file_changed:
        with open('usuarios.txt', 'w') as file:
            for key, value in users.items():
                file.write(f"{key} = '{value}'\n")
        print("Credenciales encriptadas y guardadas en 'usuarios.txt'")

# Llamar a la función para encriptar credenciales existentes al iniciar la aplicación
encrypt_existing_credentials()

# Función para verificar si el usuario ha iniciado sesión
def is_logged_in():
    return 'username' in session

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
#Funcion para iniciar sesion
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = read_user_info()
        stored_username = users.get('username')
        stored_password = users.get('password')
        if stored_username and stored_password:
            decrypted_username = decrypt_text(stored_username)
            decrypted_password = decrypt_text(stored_password)

            # Intentar desencriptar las credenciales
            if decrypted_username and decrypted_password:
                stored_username = decrypted_username
                stored_password = decrypted_password

            # Verificar las credenciales
            if username == stored_username and password == stored_password:
                session['username'] = username
                # Si las credenciales no estaban encriptadas, encriptarlas y guardarlas
                if not decrypted_username or not decrypted_password:
                    users['username'] = encrypt_text(username)
                    users['password'] = encrypt_text(password)
                    with open('usuarios.txt', 'w') as file:
                        for key, value in users.items():
                            file.write(f"{key} = '{value}'\n")
                    print("Credenciales encriptadas y actualizadas en 'usuarios.txt'")

                return redirect(url_for('formulario'))
            else:
                flash('Usuario o contraseña incorrectos.', 'danger')
        else:
            flash('Error en la configuración de usuarios.', 'danger')
    return render_template('login.html')

@app.route('/logout', methods=['POST'])
#Funcion para cerrar sesion
def logout():
    if is_logged_in():
        session.pop('username', None)
        flash('Sesión cerrada exitosamente.', 'success')
    return redirect(url_for('login'))

@app.route('/formulario')
def formulario():
    # Verifica si el usuario está logueado, si no, redirige a la página de inicio de sesión
    if not is_logged_in():
        return redirect(url_for('login'))
    campos, datos = leer_datos('informacion.txt')
    num_columnas = len(campos) // 1 + len(campos) % 2
    return render_template('formulario.html', campos=campos, datos=datos, num_columnas=num_columnas)

@app.route('/guardar', methods=['POST'])
def guardar():
    # Verifica si el usuario está logueado, si no, redirige a la página de inicio de sesión
    if not is_logged_in():
        return redirect(url_for('login'))
    datos_actuales = {}
    for campo in request.form:
        if campo != 'nuevo_campo' and campo != 'nuevo_valor' and campo != 'eliminar_campo':
            valor = request.form[campo]
            # Si el valor es un número, lo convierte a int, si no, lo deja como string
            if valor.isdigit():
                datos_actuales[campo] = int(valor)
            else:
                datos_actuales[campo] = valor

    # Obtiene el campo que se desea eliminar
    campo_a_eliminar = request.form.get('eliminar_campo')
    if campo_a_eliminar:
        #Elimina el campo del diccionario si existe
        datos_actuales.pop(campo_a_eliminar, None)
    # Abre el archivo 'informacion.txt' en modo escritura para guardar los datos actuales
    with open('informacion.txt', 'w') as file:
        for campo, valor in datos_actuales.items():
            # Escribe cada campo y su valor en el archivo, formateando según sea número o string
            if isinstance(valor, int):
                file.write(f"{campo} = {valor}\n")
            else:
                file.write(f"{campo} = \"{valor}\"\n")
    # Obtiene el nuevo campo y valor del formulario            
    nuevo_campo = request.form.get('nuevo_campo', '').strip()
    nuevo_valor = request.form.get('nuevo_valor', '').strip()
    if nuevo_campo and nuevo_valor:
        # Si el valor es un número, lo convierte a int, si no, lo deja como string
        if nuevo_valor.isdigit():
            datos_actuales[nuevo_campo] = int(nuevo_valor)
        else:
            datos_actuales[nuevo_campo] = nuevo_valor
    # Abre el archivo 'informacion.txt' nuevamente en modo escritura para agregar el nuevo campo y valor
    with open('informacion.txt', 'w') as file:
        for campo, valor in datos_actuales.items():
            # Escribe cada campo y su valor en el archivo, formateando según sea número o string
            if isinstance(valor, int):
                file.write(f"{campo} = {valor}\n")
            else:
                file.write(f"{campo} = \"{valor}\"\n")

    # Manejo del archivo adjunto (si existe)
    archivo_adjunto = request.files.get('archivo')
    if archivo_adjunto:
        # Guarda el archivo adjunto en el directorio configurado para subir archivos
        archivo_adjunto.save(os.path.join(app.config['UPLOAD_FOLDER'], archivo_adjunto.filename))
    # Redirige a la página del formulario después de guardar los datos        
    return redirect(url_for('formulario'))

@app.route('/cambiar_password', methods=['POST'])
def cambiar_password():
    # Verifica si el usuario está logueado, si no, redirige a la página de inicio de sesión
    if not is_logged_in():
        return redirect(url_for('login'))
    
    # Obtiene la nueva contraseña y la confirmación de la nueva contraseña del formulario
    nueva_password = request.form['nueva_password']
    confirm_password = request.form['confirm_password']

    # Verifica si la nueva contraseña y la confirmación coinciden
    if nueva_password != confirm_password:
        flash('Las contraseñas no coinciden.', 'danger')
        return redirect(url_for('formulario'))
    
    # Lee la información de usuario desde el archivo 'usuarios.txt' 
    users = read_user_info()
     # Encripta la nueva contraseña y la almacena en el diccionario de usuarios
    users['password'] = encrypt_text(nueva_password)

    # Abre el archivo 'usuarios.txt' en modo escritura para actualizar la contraseña
    with open('usuarios.txt', 'w') as file:
        # Escribe las credenciales actualizadas en el archivo
        for key, value in users.items():
            file.write(f"{key} = '{value}'\n")
    flash('Contraseña cambiada exitosamente.', 'success')

    # Redirige al usuario de vuelta al formulario después de cambiar la contraseña
    return redirect(url_for('formulario'))

def leer_datos(archivo):
    # Inicializa una lista para almacenar los nombres de los campos
    campos = []
    # Inicializa un diccionario para almacenar los datos
    datos = {}
    # Abre el archivo en modo lectura
    with open(archivo, 'r') as file:
        # Recorre cada línea del archivo
        for line in file:
            # Divide la línea en clave y valor usando ' = ' como separador
            key, value = line.strip().split(' = ')
            # Añade la clave a la lista de campos, quitando espacios en blanco
            campos.append(key.strip())
            # Añade la clave y el valor al diccionario de datos, quitando espacios en blanco
            datos[key.strip()] = value.strip()
    # Retorna la lista de campos y el diccionario de datos
    return campos, datos

# Código que se ejecuta solo si este archivo se ejecuta directamente
if __name__ == '__main__':
    # Verifica si la carpeta para subir archivos no existe
    if not os.path.exists(UPLOAD_FOLDER):
         # Crea la carpeta para subir archivos
        os.makedirs(UPLOAD_FOLDER)
    # Inicia la aplicación Flask en modo depuración, escuchando en todas las interfaces de red y en el puerto 5000
    app.run(debug=True, host='0.0.0.0', port=5000)

# En Windows - para activar el entorno
# .\venv\Scripts\activate
# pip install -r requirements.txt
